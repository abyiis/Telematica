#!/bin/sh
sudo apt update
sudo apt install docker-compose -y
sudo apt install git
git clone https://github.com/abyiis/Telematica
sudo unzip Telematica
cd Telematica
sudo docker-compose up -d
