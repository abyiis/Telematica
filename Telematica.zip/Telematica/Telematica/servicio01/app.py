import pygame
import random

# Inicializar pygame
pygame.init()

# Configuración de colores
BLACK = (0, 0, 0)
YELLOW = (255, 255, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)

# Configuración de la pantalla
SCREEN_WIDTH = 600
SCREEN_HEIGHT = 400
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pac-Man")

# Configuración del Pac-Man
pacman_size = 20
pacman_x = SCREEN_WIDTH // 2
pacman_y = SCREEN_HEIGHT // 2
pacman_speed = 5

# Configuración de los puntos
num_dots = 50  # Número de puntos en el laberinto
dots = []
dot_radius = 5

# Generación de puntos en posiciones aleatorias
for _ in range(num_dots):
    dot_x = random.randint(dot_radius, SCREEN_WIDTH - dot_radius)
    dot_y = random.randint(dot_radius, SCREEN_HEIGHT - dot_radius)
    dots.append((dot_x, dot_y))

# Configuración del puntaje
score = 0

# Reloj para controlar la velocidad de fotogramas
clock = pygame.time.Clock()

# Función para dibujar a Pac-Man
def draw_pacman(x, y):
    pygame.draw.circle(screen, YELLOW, (x, y), pacman_size // 2)

# Función para mostrar la puntuación
def show_score(score):
    font = pygame.font.SysFont(None, 35)
    score_text = font.render("Score: " + str(score), True, WHITE)
    screen.blit(score_text, [10, 10])

# Función principal del juego
def game_loop():
    global pacman_x, pacman_y, score
    game_over = False

    # Direcciones de movimiento de Pac-Man
    move_x = 0
    move_y = 0

    while not game_over:
        # Manejo de eventos
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    move_x = -pacman_speed
                    move_y = 0
                elif event.key == pygame.K_RIGHT:
                    move_x = pacman_speed
                    move_y = 0
                elif event.key == pygame.K_UP:
                    move_y = -pacman_speed
                    move_x = 0
                elif event.key == pygame.K_DOWN:
                    move_y = pacman_speed
                    move_x = 0

        # Movimiento de Pac-Man
        pacman_x += move_x
        pacman_y += move_y

        # Limitar el movimiento a los bordes de la pantalla
        if pacman_x < pacman_size // 2:
            pacman_x = pacman_size // 2
        elif pacman_x > SCREEN_WIDTH - pacman_size // 2:
            pacman_x = SCREEN_WIDTH - pacman_size // 2
        if pacman_y < pacman_size // 2:
            pacman_y = pacman_size // 2
        elif pacman_y > SCREEN_HEIGHT - pacman_size // 2:
            pacman_y = SCREEN_HEIGHT - pacman_size // 2

        # Comprobar si Pac-Man come un punto
        new_dots = []
        for dot in dots:
            dot_x, dot_y = dot
            if (pacman_x - dot_x) ** 2 + (pacman_y - dot_y) ** 2 < (pacman_size // 2 + dot_radius) ** 2:
                score += 1  # Incrementar el puntaje si come un punto
            else:
                new_dots.append(dot)  # Mantener los puntos no comidos
        dots[:] = new_dots  # Actualizar los puntos restantes

        # Dibujar elementos
        screen.fill(BLACK)
        draw_pacman(pacman_x, pacman_y)
        for dot in dots:
            pygame.draw.circle(screen, BLUE, dot, dot_radius)
        show_score(score)

        # Actualizar pantalla
        pygame.display.flip()
        clock.tick(30)

    # Salir de pygame
    pygame.quit()

# Ejecutar el juego
game_loop()
